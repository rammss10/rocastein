/* ROCASTEIN 5.7.8. Early isolated-world input guard. Only trusted input is
   suppressed, and only during a bounded automatic ruler placement. */
(()=>{'use strict';
 if(window.top!==window||globalThis.RocaCalibrationInputGuard)return;
 let lease=null,held=0,touches=0;
 const track=new Set(['pointerdown','pointermove','pointerup','pointercancel','mousedown','mousemove','mouseup']);
 const movement=new Set(['pointermove','pointerup','pointercancel','pointerover','pointerout','pointerenter','pointerleave','pointerrawupdate','mousemove','mouseup','mouseover','mouseout','mouseenter','mouseleave','touchmove','touchend','touchcancel']);
 function stop(l,reason){if(lease!==l)return;l.reason=reason;lease=null;clearTimeout(l.timer);l.note?.remove();}
 function live(l){return lease===l&&l.svg.isConnected&&l.path===location.pathname&&document.body?.classList.contains('wc-calibrating')&&!document.hidden;}
 function onInput(e){
  if(!e.isTrusted)return;
  if(track.has(e.type)&&typeof e.buttons==='number')held=e.buttons;
  if(e.touches)touches=e.touches.length;
  const l=lease;if(!l)return;
  if(!live(l)){stop(l,'Cambió la pestaña o terminó el modo de calibración.');return;}
  // The page may listen for drag events on document/window, even when the
  // cursor leaves the image. Suppress real move/release events across this tab.
  // Synthetic events used by the ruler are never blocked.
  const rect=l.svg.getBoundingClientRect();
  const path=e.composedPath();
  const point=typeof e.clientX==='number'?e:e.touches?.[0]||e.changedTouches?.[0];
  const inside=path.includes(l.svg)||path.includes(l.img)||path.includes(l.container)||
   (point&&point.clientX>=rect.left&&point.clientX<=rect.right&&point.clientY>=rect.top&&point.clientY<=rect.bottom);
  if(!movement.has(e.type)&&!inside)return;
  if(e.cancelable)e.preventDefault();e.stopImmediatePropagation();
 }
 const events=new Set([...movement,...track,'click','dblclick','auxclick','contextmenu','wheel','dragstart','drag','dragend','dragover','drop','touchstart']);
 for(const type of events)window.addEventListener(type,onInput,{capture:true,passive:false});
 function interrupted(){held=0;touches=0;if(lease)stop(lease,'Se interrumpió la calibración al cambiar de ventana o pestaña.');}
 window.addEventListener('blur',interrupted);window.addEventListener('pagehide',interrupted);document.addEventListener('visibilitychange',()=>{if(document.hidden)interrupted();});
 globalThis.RocaCalibrationInputGuard=Object.freeze({
  start(svg,img){
   if(lease)throw Error('Ya hay una calibración en curso.');
   if(held||touches)throw Error('Suelta el botón del mouse y vuelve a detectar las marcas.');
   if(!svg?.isConnected||!img?.isConnected||document.hidden||!document.body?.classList.contains('wc-calibrating'))throw Error('Abre la calibración antes de colocar la regla.');
   const l={svg,img,container:svg.closest('.imageContainer')||svg.parentElement,path:location.pathname,reason:null,note:null,timer:null};
   const note=document.createElement('div');note.setAttribute('role','status');note.style.cssText='position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483647;pointer-events:none;max-width:90vw;';
   const shadow=note.attachShadow({mode:'closed'});shadow.innerHTML='<style>div{font:600 13px/1.45 system-ui;color:#fff;background:#176e50;padding:10px 16px;border-radius:10px;box-shadow:0 4px 18px #183b4050;text-align:center}small{font-weight:400;display:block;color:#e4f6ed}i{display:inline-block;width:11px;height:11px;border:2px solid #ffffff66;border-top-color:white;border-radius:50%;vertical-align:-2px;margin-right:8px;animation:spin .8s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){i{animation:none}}</style><div><i></i>Calibrando automáticamente…<small>Movimiento del mouse protegido durante el ajuste.</small></div>';
   document.documentElement.append(note);l.note=note;lease=l;l.timer=setTimeout(()=>stop(l,'Se agotó el tiempo de protección. Revisa la calibración.'),45000);
   return Object.freeze({check(){if(!live(l)){stop(l,'Cambió la radiografía o la calibración.');throw Error(l.reason||'Se interrumpió la protección del mouse.');}},release(){stop(l,'Finalizado.');}});
  }
 });
})();
