/* Local-only detector. Inputs are pixels of the visible radiograph crop. */
(function(root){'use strict';
// Equal spacing model p(i) = center + (i-1.5)*step.
// Least squares uses all four centers, not just the two outer marks.
function fitFour(points){
 if(!Array.isArray(points)||points.length!==4||points.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw Error('Se requieren cuatro centros válidos.');
 const center=points.reduce((a,p)=>({x:a.x+p.x/4,y:a.y+p.y/4}),{x:0,y:0});
 const step=points.reduce((a,p,i)=>({x:a.x+(i-1.5)*p.x/5,y:a.y+(i-1.5)*p.y/5}),{x:0,y:0});
 const fitted=points.map((_,i)=>({x:center.x+(i-1.5)*step.x,y:center.y+(i-1.5)*step.y}));
 const errors=points.map((p,i)=>Math.hypot(p.x-fitted[i].x,p.y-fitted[i].y));
 return {points:fitted,spacing:Math.hypot(step.x,step.y),rms:Math.sqrt(errors.reduce((a,v)=>a+v*v,0)/4),maxError:Math.max(...errors)};
}
function detect(data,w,h,opts={}){
 if(w<70||h<90||w*h>4000000)return {ok:false,reason:'Zona de imagen insuficiente.'};
 const gray=new Float32Array(w*h),mask=new Uint8Array(w*h),score=new Float32Array(w*h),rad=new Uint8Array(w*h);
 for(let i=0;i<w*h;i++){let p=i*4,r=data[p],g=data[p+1],b=data[p+2];gray[i]=.299*r+.587*g+.114*b;mask[i]=Math.max(r,g,b)-Math.min(r,g,b)<=25?1:0;}
 const v=(x,y)=>gray[y*w+x];
 // The physical marks are compact bright peaks along the left edge of a long gray support.
 // Vertical differential removes the background edge without using an absolute brightness threshold.
 const scale=Math.max(.65,opts.scale||1),R=Math.max(2,Math.min(7,Math.ceil(3*scale))),margin=2*R+3;
 for(let y=margin;y<h-margin;y++)for(let x=margin;x<w-margin;x++){
  const i=y*w+x;if(!mask[i])continue;
  for(let r=1;r<=R;r++){
   let core=0,bg=0,peak=0,n=0,valid=true;
   for(let dx=-r;dx<=r;dx++){
    for(let dy=-r;dy<=r;dy++)if(!mask[(y+dy)*w+x+dx])valid=false;
    let base=(v(x+dx,y-r-2)+v(x+dx,y+r+2)+v(x+dx,y-r-3)+v(x+dx,y+r+3))/4;
    for(let dy=-r;dy<=r;dy++){let z=v(x+dx,y+dy)-base;core+=z;peak=Math.max(peak,z);n++;}
    bg+=base;
   }
   if(!valid||peak<8)continue;
   let value=core/n+peak*.20;
   if(value>score[i]){score[i]=value;rad[i]=r;}
  }
 }
 const raw=[];for(let y=margin;y<h-margin;y++)for(let x=margin;x<w-margin;x++){
  let i=y*w+x,s=score[i];if(s<5.5)continue;let isMax=true;for(let dy=-2;dy<=2&&isMax;dy++)for(let dx=-2;dx<=2;dx++)if(score[i+dy*w+dx]>s){isMax=false;break}if(isMax)raw.push({x,y,s,r:rad[i]});
 }
 raw.sort((a,b)=>b.s-a.s);const pts=[];for(const p of raw){if(pts.every(q=>Math.hypot(q.x-p.x,q.y-p.y)>Math.max(3,scale*2.1)))pts.push(p);if(pts.length>=700)break;}
 const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 function refine(p){const r=Math.max(2,p.r+1),x=p.x,y=p.y;let sum=0,sx=0,sy=0,peak=0,values=[];if(x-r<0||x+r>=w||y-r-3<0||y+r+3>=h)return p;
 for(let dx=-r;dx<=r;dx++){let top=(v(x+dx,y-r-2)+v(x+dx,y-r-3))/2,bot=(v(x+dx,y+r+2)+v(x+dx,y+r+3))/2;for(let dy=-r;dy<=r;dy++){if(!mask[(y+dy)*w+x+dx]||Math.hypot(dx,dy)>r+.2)continue;let z=Math.max(0,v(x+dx,y+dy)-(top+(bot-top)*(dy+r+2)/(2*r+4)));peak=Math.max(peak,z);values.push([x+dx,y+dy,z]);}}
 for(const [xx,yy,z] of values){let a=Math.max(0,z-.25*peak)**1.5;sum+=a;sx+=a*xx;sy+=a*yy;}return sum&&Math.hypot(sx/sum-x,sy/sum-y)<=r?{...p,x:sx/sum,y:sy/sum}:p;}
 // Require the gray support continuously between the four spots, not just at isolated peaks.
 function strip(p,g){let valid=0,n=0,edge=0,rightEdge=0;const a=p[0],b=p[3];let d=Math.max(3,Math.round(g*.17));
  for(let k=0;k<25;k++){let t=(k+.5)/25,x=Math.round(a.x+(b.x-a.x)*t),y=Math.round(a.y+(b.y-a.y)*t);if(x-2*d<0||x+2*d>=w||y<0||y>=h)continue;let l=0,r=0,c=0;for(let j=d;j<2*d;j++){l+=v(x-j,y);r+=v(x+j,y);c++;}l/=c;r/=c;n++;if(r-l>7&&r>12&&r<190){valid++;edge+=r-l;
   // A finite metal strip should return toward its dark surroundings on the right.
   let found=false;for(let j=Math.max(2*d,Math.round(g*.4));j<=Math.round(g*1.9)&&x+j+2<w;j++){let far=(v(x+j,y)+v(x+j+1,y)+v(x+j+2,y))/3;if(far<r-Math.max(7,(r-l)*.35)){found=true;break;}}if(found)rightEdge++;
  }}
  return n>=20&&valid/n>=.80&&rightEdge/valid>=.70?edge/valid:0;
 }
 function peakAt(x,y,r){let best=0;for(let yy=Math.max(0,Math.floor(y-r));yy<=Math.min(h-1,Math.ceil(y+r));yy++)for(let xx=Math.max(0,Math.floor(x-r));xx<=Math.min(w-1,Math.ceil(x+r));xx++)best=Math.max(best,score[yy*w+xx]);return best;}
 const groups=[],min=opts.minGap||Math.max(9,9*scale),max=opts.maxGap||h*.28;
 // Bucket points in y bands so lookup is not cubic.
 const buckets=Array.from({length:h},()=>[]);for(const p of pts)buckets[p.y].push(p);
 function near(x,y,tol,used){let best=null,bd=Infinity;for(let yy=Math.max(0,Math.floor(y-tol));yy<=Math.min(h-1,Math.ceil(y+tol));yy++)for(const p of buckets[yy]){let d=Math.hypot(p.x-x,p.y-y);if(d<=tol&&!used.includes(p)&&d<bd){best=p;bd=d;}}return best;}
 for(const a of pts)for(const b of pts){let dy=b.y-a.y,dx=b.x-a.x;if(dy<min||dy>max||Math.abs(dx)>Math.max(2,dy*.085))continue;let tol=Math.max(2.5,dy*.085);const c=near(a.x+2*dx,a.y+2*dy,tol,[a,b]);if(!c)continue;const d=near(a.x+3*dx,a.y+3*dy,tol,[a,b,c]);if(!d)continue;const pp=[a,b,c,d],minS=Math.min(...pp.map(p=>p.s)),meanS=pp.reduce((a,p)=>a+p.s,0)/4;if(minS<5.5||meanS<8)continue;
 const fit=fitFour(pp),gap=fit.spacing;if(fit.maxError>Math.max(1.8, gap*.055))continue;
 const support=strip(pp,gap);if(!support)continue;
 // A valid sequence must be consecutive; reject an interleaved train of highlights.
 let skipped=false;for(const f of [1/3,.5,2/3]){let hits=0;for(let k=0;k<3;k++){const p=fit.points[k],q=fit.points[k+1];if(peakAt(p.x+(q.x-p.x)*f,p.y+(q.y-p.y)*f,Math.max(2,Math.min(4,gap*.09)))>=Math.max(5.0,minS*.42))hits++;}if(hits>=2)skipped=true;}if(skipped)continue;
 // Extra similarly bright, regularly spaced marks make the 30 mm assignment uncertain.
 if([-1,4].some(k=>{let p=fit.points[0],q=fit.points[1],x=p.x+k*(q.x-p.x),y=p.y+k*(q.y-p.y);return peakAt(x,y,Math.max(2,gap*.055))>=Math.max(7,minS*.75)&&!!near(x,y,tol,pp)}))continue;
 groups.push({pp,fit,score:minS*.7+meanS*.3+Math.min(35,support)*.12-fit.rms*2});
 }
 groups.sort((a,b)=>b.score-a.score);const best=groups[0];if(!best)return {ok:false,reason:'No se encontraron cuatro marcas consecutivas verificables.'};
 const alt=groups.find(g=>dist(g.pp[0],best.pp[0])>Math.max(4,best.fit.spacing*.18)||dist(g.pp[3],best.pp[3])>Math.max(4,best.fit.spacing*.18));if(alt&&alt.score>=best.score*.80)return {ok:false,reason:'Más de una secuencia compatible; no se aplicó calibración.'};
 const points=best.pp.map(refine),fit=fitFour(points),gap=fit.spacing,gaps=points.slice(1).map((p,i)=>dist(p,points[i])),err=Math.max(...gaps.map(v=>Math.abs(v-gap)))/gap;
 if(err>.065||fit.maxError>Math.max(1.05*scale,gap*.025))return {ok:false,reason:'El ajuste de las cuatro marcas no es uniforme.'};
 return {ok:true,points:points.map(({x,y})=>({x,y})),fitted:fit.points,fitRms:fit.rms,fitMax:fit.maxError,relativeError:err,spacing:gap};
}
root.RocaCalibrationDetect={detect,fitFour};if(typeof module!=='undefined')module.exports={detect,fitFour};
})(globalThis);
