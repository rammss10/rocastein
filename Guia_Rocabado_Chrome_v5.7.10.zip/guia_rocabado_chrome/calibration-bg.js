/* Capture only on an explicit request from the active WebCeph tab.
   activeTab permission is granted by clicking the extension toolbar action. */
(()=>{
 const allowed=u=>{try{const x=new URL(u);return ['https://webceph.com','https://www.webceph.com'].includes(x.origin)&&/\/digitization\/?$/i.test(x.pathname)}catch{return false}};
 chrome.runtime.onMessage.addListener((m,s,reply)=>{
  if(!['roc-cal-capture','roc-cal-original'].includes(m?.type))return;
  if(s.id!==chrome.runtime.id||s.frameId!==0||!s.tab?.id||!allowed(s.url)){reply({ok:false,message:'Abre la digitalización en WebCeph.'});return;}
  (async()=>{
   const t=await chrome.tabs.get(s.tab.id);if(!t.active||t.url!==s.url)throw Error('La pestaña o la radiografía cambió.');
   const w=await chrome.windows.get(t.windowId);if(!w.focused)throw Error('Selecciona la ventana de WebCeph.');
   let image,source='screen';
   if(m.type==='roc-cal-original'){
    const u=new URL(m.src||'');if(u.origin!=='https://secure-images.webceph.com'||!u.pathname.startsWith('/media-')||! /\.(?:jpe?g|png)$/i.test(u.pathname)||u.username||u.password)throw Error('Origen de imagen no compatible.');
    // Only retrieve the already displayed image from its original authorized host.
    // Never send pixels or URLs to another service, and never persist the bytes.
    const res=await fetch(u.href,{credentials:'include',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(12000)});
    if(!res.ok||!/^image\/(?:jpeg|png)(?:;|$)/i.test(res.headers.get('content-type')||''))throw Error('El servidor de la imagen no autorizó la lectura.');
    const cap=20*1024*1024;const length=Number(res.headers.get('content-length')||0);if(length>cap)throw Error('Imagen demasiado grande.');
    const reader=res.body.getReader();let chunks=[],total=0;try{while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>cap)throw Error('Imagen demasiado grande.');chunks.push(value);}}finally{await reader.cancel().catch(()=>{});}
    let binary='';for(const chunk of chunks)for(let i=0;i<chunk.length;i+=8192)binary+=String.fromCharCode(...chunk.subarray(i,i+8192));image='data:'+res.headers.get('content-type').split(';')[0]+';base64,'+btoa(binary);source='original';
   }else image=await chrome.tabs.captureVisibleTab(t.windowId,{format:'png'});
   const after=await chrome.tabs.get(t.id);if(!after.active||after.url!==t.url||!(await chrome.windows.get(t.windowId)).focused)throw Error('La pestaña cambió durante la captura.');
   return {ok:true,image,source};
  })().then(reply,e=>reply({ok:false,message:/permission|activeTab|Cannot access|all_urls/i.test(e.message)?'Pulsa el icono ROCASTEIN de Chrome y después Auto calibrar para autorizar esta captura local.':(m.type==='roc-cal-original'?'No se pudo leer la imagen desde su origen.':e.message)}));return true;
 });
})();
