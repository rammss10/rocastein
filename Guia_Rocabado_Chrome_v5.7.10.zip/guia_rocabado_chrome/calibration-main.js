/* ROCASTEIN: restricted page-realm fractional ruler events. No network, storage,
   anatomy mutations, direct calibration field edits or arbitrary code execution. */
(()=>{'use strict';
 const name='roc-cal-fractional-v577';let active=null,dragState=null;
 const allowed=new Set(['mousedown','mousemove','mouseup']);
 function bind(){const svg=document.querySelector('svg#original_canvas');if(!svg||svg===active)return;active=svg;dragState=null;
  svg.addEventListener(name,ev=>{try{
   if(ev.target!==svg||!svg.isConnected||!document.body?.classList.contains('wc-calibrating')||! /\/digitization\/?$/i.test(location.pathname)||typeof ev.detail!=='string'||ev.detail.length>300)return;
   const d=JSON.parse(ev.detail);if(!['ref10','ref0'].includes(d.id)||!allowed.has(d.phase)||!['svg','handle'].includes(d.route)||!Number.isFinite(d.x)||!Number.isFinite(d.y))return;
   const el=svg.querySelector('circle#'+d.id),matrix=el?.getScreenCTM();if(!matrix)return;
   const pt=new DOMPoint(d.x,d.y).matrixTransform(matrix);if(!Number.isFinite(pt.x)||!Number.isFinite(pt.y)||pt.x<0||pt.y<0||pt.x>innerWidth||pt.y>innerHeight)return;
   const rect=svg.getBoundingClientRect();if(pt.x<rect.left-1||pt.x>rect.right+1||pt.y<rect.top-1||pt.y>rect.bottom+1)return;
   if(d.phase==='mousedown'){const start=new DOMPoint(Number(el.getAttribute('cx')),Number(el.getAttribute('cy'))).matrixTransform(matrix);if(Math.hypot(start.x-pt.x,start.y-pt.y)>2)return;dragState={id:d.id,route:d.route,expires:performance.now()+3000};}else if(!dragState||dragState.id!==d.id||dragState.route!==d.route||performance.now()>dragState.expires){dragState=null;return;}
   if(d.phase==='mouseup')dragState=null;
   const target=d.phase==='mousedown'||d.route==='handle'?el:svg;
   const event=new MouseEvent(d.phase,{bubbles:true,cancelable:true,view:window,clientX:pt.x,clientY:pt.y,button:0,buttons:d.phase==='mouseup'?0:1});
   // Chromium MouseEvent may expose integers. The page realm's own properties
   // carry the exact fractional coordinates to standard/jQuery listeners.
   const props={clientX:pt.x,clientY:pt.y,x:pt.x,y:pt.y,pageX:pt.x+scrollX,pageY:pt.y+scrollY};
   for(const [key,value] of Object.entries(props))Object.defineProperty(event,key,{value,configurable:true});
   ev.preventDefault();target.dispatchEvent(event);
  }catch{}},false);
 }
 bind();new MutationObserver(bind).observe(document.documentElement,{childList:true,subtree:true});
})();
