importScripts('rules.js');
const key='rocaPendingV45',config='rocaFormV45',managed='rocaManagedV49';
const web=u=>/^https:\/\/(?:www\.)?webceph\.com\//i.test(u||'');
function formURL(raw){try{const u=new URL(raw);if(u.origin==='https://docs.google.com'&&/^\/forms\/d\/(?:e\/)?[A-Za-z0-9_-]+\/viewform\/?$/.test(u.pathname))return u.origin+u.pathname.replace(/\/$/,'');}catch{}return null;}
let queue=Promise.resolve();
chrome.runtime.onMessage.addListener((m,s,reply)=>{
 if(!s.url||s.frameId!==0||!Number.isInteger(s.tab?.id))return;
 const url=formURL(s.url), type=m?.type;
 if(!(['roca-stage','roca-clear'].includes(type)&&web(s.url)||['roca-get','roca-consume','roca-link-form'].includes(type)&&url))return;
 const work=async()=>{
 if(type==='roca-link-form'){
   if(m.confirmed!==true)return {ok:false};
   await chrome.storage.local.set({[config]:url});await chrome.storage.session.remove(key);await chrome.storage.session.remove(managed);
   return {ok:true,message:'Formulario vinculado. Regresa a WebCeph y pulsa Abrir Forms rellenado.'};
 }
 if(type==='roca-stage'){
 let target;try{target=formURL((await chrome.storage.local.get(config))[config]);}catch{return {ok:false,code:'storage'};}if(!target)return {ok:false,needsLink:true};
 const d=m.data||{}, R=globalThis.RocaRules,clean={};for(const [id,,kind] of R.fields){const v=d[id];if(kind==='number'?typeof v!=='number'||!Number.isFinite(v):typeof v!=='string'||v.length>25)throw Error('invalid');clean[id]=v;}
 if(!['F','M'].includes(clean.sex)||!Number.isInteger(clean.age)||clean.age<0||clean.age>120||!['Positiva','Negativa','Nula'].includes(clean.hyoidClass))throw Error('invalid');for(const id of ['anb','angle','c01','c12'])if(!R.cls(id,clean[id])||R.cls(id,clean[id])!==clean[id+'Class'])throw Error('invalid');
 let previous;try{await chrome.storage.session.remove(key);previous=(await chrome.storage.session.get(managed))[managed];}catch{return {ok:false,code:'storage'};}
 let tab;
 if(previous?.url===target&&Number.isInteger(previous.id)){try{const r=await chrome.tabs.sendMessage(previous.id,{type:'roca-check-managed',url:target},{frameId:0});if(r?.ok){await chrome.tabs.update(previous.id,{url:'about:blank'});tab={id:previous.id};}}catch{tab=null;}}
 let created=false;try{if(!tab){tab=await chrome.tabs.create({url:'about:blank',active:false,windowId:s.tab.windowId});created=true;}}catch{return {ok:false,code:'tabs'};}
 async function cleanup(){try{await chrome.storage.session.remove([key,managed]);}catch{}if(created){try{await chrome.tabs.remove(tab.id);}catch{}}}
 try{await chrome.storage.session.set({[key]:{data:clean,ticket:crypto.randomUUID(),expires:Date.now()+15*60*1000,owner:s.tab.id,dest:tab.id,url:target},[managed]:{id:tab.id,url:target}});}catch{await cleanup();return {ok:false,code:'storage'};}
 try{await chrome.tabs.update(tab.id,{url:target,active:true});}catch{await cleanup();return {ok:false,code:'tabs'};}

 return {ok:true};}
 const p=(await chrome.storage.session.get(key))[key];
 if(type==='roca-clear'){if(p?.owner===s.tab.id)await chrome.storage.session.remove(key);return {ok:true};}
 if(!p||p.expires<Date.now()||p.dest!==s.tab.id||p.url!==url){if(p&&p.expires<Date.now())await chrome.storage.session.remove(key);return {ok:false};}
 if(type==='roca-consume'){if(m.ticket!==p.ticket)return {ok:false};await chrome.storage.session.remove(key);return {ok:true};}
 return {ok:true,data:p.data,ticket:p.ticket};
 };
 const job=queue.then(work);queue=job.catch(()=>{});job.then(reply,()=>reply({ok:false,code:'unknown'}));return true;
});
chrome.tabs.onRemoved.addListener(async id=>{const p=(await chrome.storage.session.get(key))[key];if(p?.dest===id||p?.owner===id)await chrome.storage.session.remove(key);const t=(await chrome.storage.session.get(managed))[managed];if(t?.id===id)await chrome.storage.session.remove(managed);});

importScripts('update.js');

importScripts('calibration-bg.js');
