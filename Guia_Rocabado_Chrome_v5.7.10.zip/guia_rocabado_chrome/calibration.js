/* ROCASTEIN 5.7.10 pilot. Read the displayed image only from its authorized WebCeph origin; process locally; save only on explicit confirmation. */
(()=>{'use strict';
 if(window.top!==window||document.getElementById('roc-calibration-pilot'))return;
 const host=document.createElement('div');host.id='roc-calibration-pilot';host.style.cssText='position:fixed;right:12px;top:clamp(12px,40vh,calc(100vh - 370px));width:min(260px,calc(100vw - 24px));max-height:calc(100vh - 24px);overflow:auto;z-index:2147483647;display:none;';document.documentElement.append(host);
 const s=host.attachShadow({mode:'closed'});s.innerHTML=`<style>:host{color-scheme:light}.box{font:12px/1.4 system-ui;color:#20364c;background:white;border:1px solid #bdcbd8;border-radius:10px;box-shadow:0 6px 20px #182c4340;overflow:hidden}.head{background:#20364c;color:white;font-weight:700;padding:9px 12px}.body{padding:12px}button{display:block;width:100%;margin-top:7px;border:0;border-radius:6px;padding:9px;background:#176e50;color:white;font:600 12px system-ui;cursor:pointer}button.secondary{background:#e8eff5;color:#20364c}button[hidden]{display:none}button:disabled{opacity:.55;cursor:default}#status{margin:8px 0;color:#3e5367}small{display:block;color:#657589;margin-top:8px}</style><section class="box"><div class="head">ROCASTEIN · Auto calibrar · 5.7.10</div><div class="body"><b>Regla de referencia · 30 mm</b><button id="detect">Detectar 4 marcas</button><div id="status" role="status">Mantén visibles las cuatro marcas blancas.</div><button id="apply" hidden>Colocar regla roja</button><button id="review" class="secondary" hidden>Comprobar ajuste manual</button><button id="save" hidden>Guardar calibración y cerrar</button><button id="cancel" class="secondary" hidden>Cancelar / quitar marcas</button><small>Verifica la longitud física, los extremos y los px/mm. No fija una calibración predeterminada. Guarda solo después de revisar.</small></div></section>`;
 const q=id=>s.getElementById(id),say=t=>q('status').textContent=t,delay=n=>new Promise(r=>setTimeout(r,n));let fineUsed=false,pending=null,busy=false,overlay=null,ready=null,wasOn=false,scheduled=false,caseKey=null,autoTimer=null,assistToken=null,manualReview=null, saving=false;
 const mode=()=>/\/digitization\/?$/i.test(location.pathname)&&document.body.classList.contains('wc-calibrating');
 function clear(){pending=null;ready=null;assistToken=null;manualReview=null;q('review').hidden=true;q('save').hidden=true;overlay?.remove();overlay=null;q('apply').hidden=true;q('cancel').hidden=true;}
 function endpoints(){const svg=document.querySelector('svg#original_canvas'),a=svg?.querySelector('circle#ref10'),b=svg?.querySelector('circle#ref0'),img=document.querySelector('img#original');if(!a||!b||!img||!img.complete||!img.naturalWidth)throw Error('Abre Calibrar imagen y espera a que cargue la radiografía.');return {svg,a,b,img};}
 function fields(){const modal=document.querySelector('#guide_ruler_set_modal');if(!modal)throw Error('Abre Calibrar imagen.');const sel=[...modal.querySelectorAll('select')].find(e=>/\bmm\b/i.test(e.selectedOptions[0]?.textContent||''));if(!sel||!/^\s*30\s*mm\s*$/i.test(sel.selectedOptions[0].textContent))throw Error('Selecciona la regla de 30 mm en WebCeph.');let input=null;const labels=[...modal.querySelectorAll('label,div,span,p,strong,b')].filter(e=>/^(p[ií]xeles por mil[ií]metro|pixels per millimeter|pixels per mm)$/i.test(e.textContent.trim()));for(const label of labels){for(let p=label;p&&p!==modal;p=p.parentElement){let list=[...p.querySelectorAll('input')].filter(x=>x.type!=='checkbox'&&x.type!=='hidden'&&x.type!=='radio'&&/^\d+(?:[.,]\d+)?$/.test(x.value));if(list.length===1){input=list[0];break}}if(input)break;}
 if(!input){const list=[...modal.querySelectorAll('input')].filter(x=>!['hidden','checkbox','radio'].includes(x.type)&&/^\d+[.,]\d+$/.test(x.value)&&x.getBoundingClientRect().width>0);if(list.length===1)input=list[0];}
 if(!input)throw Error('No se pudo identificar el campo px/mm. Calibra manualmente.');const ppm=Number(input.value.replace(',','.'));if(!Number.isFinite(ppm)||ppm<=0)throw Error('El valor px/mm no es válido.');return {sel,input,ppm};}
 const coord=e=>({x:Number(e.getAttribute('cx')),y:Number(e.getAttribute('cy'))});
 function screen(e){const p=coord(e),m=e.getScreenCTM();if(!m||!Number.isFinite(p.x)||!Number.isFinite(p.y))throw Error('No se pueden leer los extremos.');return new DOMPoint(p.x,p.y).matrixTransform(m);}
 const dist=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y);
 const bounds=el=>{const r=el.getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height,right:r.right,bottom:r.bottom}};
 function fingerprint(e){return JSON.stringify({path:location.pathname,src:e.img.currentSrc,rect:bounds(e.img),svg:bounds(e.svg),coords:[coord(e.a),coord(e.b)],ppm:fields().ppm,vw:innerWidth,vh:innerHeight,scroll:[scrollX,scrollY]});}
 function layoutKey(e){return JSON.stringify({path:location.pathname,src:e.img.currentSrc,rect:bounds(e.img),svg:bounds(e.svg),vw:innerWidth,vh:innerHeight,scroll:[scrollX,scrollY]});}
 function showMarks(points){overlay=document.createElement('div');overlay.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:2147483645;';for(let i=0;i<4;i++){const el=document.createElement('span');el.style.cssText=`position:absolute;left:${points[i].x}px;top:${points[i].y}px;transform:translate(-50%,-50%);width:9px;height:9px;box-sizing:border-box;border:1px solid #40ea8d;border-radius:50%;`;for(const css of ['width:13px;height:1px;left:-3px;top:3px;background:linear-gradient(to right,#40ea8d 0 35%,transparent 35% 65%,#40ea8d 65%);','width:1px;height:13px;left:3px;top:-3px;background:linear-gradient(to bottom,#40ea8d 0 35%,transparent 35% 65%,#40ea8d 65%);']){const tick=document.createElement('span');tick.style.cssText='position:absolute;'+css;el.append(tick);}const label=document.createElement('span');label.textContent=String(i+1);label.style.cssText='position:absolute;left:13px;top:-4px;background:#145d42;color:white;font:700 10px system-ui;padding:0 3px;border-radius:3px';el.append(label);overlay.append(el);}document.documentElement.append(overlay);}
 // Prefer the full original image, independent of zoom and scrolling. For the
 // optional screen fallback, temporarily hide only the SVG overlay (not its geometry).
 async function captureClean(e,token){
  let r;try{r=await chrome.runtime.sendMessage({type:'roc-cal-original',src:e.img.currentSrc});}catch{}
  if(r?.ok)return r;
  const svg=e.svg,old=svg.style.getPropertyValue('visibility'),priority=svg.style.getPropertyPriority('visibility');
  try{svg.style.setProperty('visibility','hidden','important');await delay(140);if(!mode()||fingerprint(endpoints())!==token)throw Error('Cambió la radiografía.');r=await chrome.runtime.sendMessage({type:'roc-cal-capture'});return r;}
  finally{if(old)svg.style.setProperty('visibility',old,priority);else svg.style.removeProperty('visibility');}
 }
 async function detect(){if(busy)return;clear();busy=true;q('detect').disabled=true;say('Buscando cuatro marcas…');try{
 if(!mode())throw Error('Primero abre Calibrar imagen en WebCeph.');const e=endpoints();fields();const token=fingerprint(e),rect=bounds(e.img);
 host.style.visibility='hidden';let r=await captureClean(e,token);if(!r?.ok)throw Error('No se pudo acceder a la imagen original ni a la captura. Calibra manualmente. La captura alternativa puede requerir autorizarla desde el icono de Chrome.');
 if(!mode()||fingerprint(endpoints())!==token)throw Error('Cambió la imagen o el zoom. Vuelve a detectar.');
 const bmp=await createImageBitmap(await (await fetch(r.image)).blob());let result,sx,sy,ix,iy;const original=r.source==='original';try{
 sx=original?bmp.width/rect.width:bmp.width/innerWidth;sy=original?bmp.height/rect.height:bmp.height/innerHeight;if(Math.abs(sx/sy-1)>.025)throw Error('La imagen no coincide con las proporciones visibles.');
 const ox=original?rect.left:0,oy=original?rect.top:0;
 const x0=original?rect.left+rect.width*.62:Math.max(0,rect.left+rect.width*.62),x1=original?rect.left+rect.width*.97:Math.min(innerWidth,rect.left+rect.width*.97),y0=original?rect.top+rect.height*.035:Math.max(0,rect.top+rect.height*.035),y1=original?rect.top+rect.height*.72:Math.min(innerHeight,rect.top+rect.height*.72);
 ix=Math.max(0,Math.ceil((x0-ox)*sx));iy=Math.max(0,Math.ceil((y0-oy)*sy));const w=Math.min(bmp.width,Math.floor((x1-ox)*sx))-ix,h=Math.min(bmp.height,Math.floor((y1-oy)*sy))-iy;
 if(w<70||h<90)throw Error('Muestra la regla completa de la radiografía.');
 // Normalize the image resolution for consistent blob sizes across export formats.
 const ratio=Math.min(1,1400/(rect.width*sx),Math.sqrt(1600000/(w*h)));const cw=Math.floor(w*ratio),ch=Math.floor(h*ratio);const c=document.createElement('canvas');c.width=cw;c.height=ch;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(bmp,ix,iy,w,h,0,0,cw,ch);const pixels=ctx.getImageData(0,0,cw,ch),imageWidth=rect.width*sx*cw/w;
 result=RocaCalibrationDetect.detect(pixels.data,cw,ch,{scale:Math.max(.65,imageWidth/1000),minGap:imageWidth*.022,maxGap:imageWidth*.085});
 if(result.ok){const map=p=>({x:(p.x+.5)*w/cw-.5,y:(p.y+.5)*h/ch-.5});result.points=result.points.map(map);result.fitted=result.fitted.map(map);}c.width=0;c.height=0;
 }finally{bmp.close()}
 const source=original?'imagen original':'captura local sin trazado';
 if(!result.ok)throw Error(result.reason+' Fuente: '+source+'. Puedes calibrar manualmente.');if(!mode()||fingerprint(endpoints())!==token)throw Error('Cambió la radiografía. Vuelve a detectar.');const toScreen=p=>({x:(p.x+ix+.5)/sx+(original?rect.left:0),y:(p.y+iy+.5)/sy+(original?rect.top:0)});const raw=result.points.map(toScreen),points=result.fitted.map(toScreen);
 if(points.some(p=>p.x<3||p.x>innerWidth-3||p.y<3||p.y>innerHeight-3))throw Error('Se detectó la regla, pero no está completamente visible. Desplaza la página y pulsa Detectar 4 marcas.');
 const fitRms=Math.sqrt(raw.reduce((t,p,i)=>t+dist(p,points[i])**2,0)/4);const m=e.a.getScreenCTM()?.inverse();if(!m)throw Error('No se pudo convertir las coordenadas.');const a=new DOMPoint(points[0].x,points[0].y).matrixTransform(m),b=new DOMPoint(points[3].x,points[3].y).matrixTransform(m);const expected=dist(a,b)/30;if(!Number.isFinite(expected)||expected<=0)throw Error('Escala inválida.');
 pending={token,points,raw,expected,fitRms,source};showMarks(raw);q('apply').hidden=false;q('cancel').hidden=false;say('4 marcas detectadas · '+source+'. Estimación: '+expected.toFixed(3)+' px/mm. Colocando regla…');scheduled=true;setTimeout(()=>{scheduled=false;if(pending&&!busy)apply();},350);
 }catch(e){clear();say(e.message||'No se pudo detectar. Calibra manualmente.');}finally{host.style.visibility='';busy=false;q('detect').disabled=false;}}
 // Dispatch the real ruler's visible handles, with the hit-tested SVG routing
 // used in 5.7.2 as the first strategy. Never dispatch to anatomical circles.
 // Work in SVG coordinates and forward fractional screen/page coordinates to
 // WebCeph's own handlers in the page realm. No cx/cy or ppm writes.
 function localTarget(el,p){const m=el.getScreenCTM();if(!m)throw Error('No se pudo leer la transformación SVG.');const q=new DOMPoint(p.x,p.y).matrixTransform(m.inverse());return {x:q.x,y:q.y};}
 function fireFine(el,type,p,buttons,route){const svg=el.ownerSVGElement,pt=localTarget(el,p);const detail=JSON.stringify({id:el.id,phase:type,x:pt.x,y:pt.y,route});const ev=new CustomEvent('roc-cal-fractional-v577',{detail,cancelable:true});return !svg.dispatchEvent(ev);}
 function fire(target,type,p,buttons){target.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window,clientX:Math.round(p.x),clientY:Math.round(p.y),button:0,buttons}));}
 function receiver(el,p,variant){const svg=el.ownerSVGElement;if(variant===1)return svg;if(variant===2)return el;
  const hit=document.elementFromPoint(p.x,p.y);return hit===el||hit===svg?hit:svg;
 }
 async function drag(el,target,variant=0){const start=screen(el);if(dist(start,target)<.08)return;
  const fractional=variant===3||variant===4;
  if(fractional){const route=variant===4?'handle':'svg';if(!fireFine(el,'mousedown',start,1,route))return;
   try{for(let i=1;i<=4;i++){const p={x:start.x+(target.x-start.x)*i/4,y:start.y+(target.y-start.y)*i/4};if(!fireFine(el,'mousemove',p,1,route))break;await delay(15);}}finally{fireFine(el,'mouseup',target,0,route);}await delay(100);return;
  }
  fire(el,'mousedown',start,1);try{for(let i=1;i<=6;i++){const p={x:start.x+(target.x-start.x)*i/6,y:start.y+(target.y-start.y)*i/6};fire(receiver(el,p,variant),'mousemove',p,1);await delay(16);}}finally{fire(receiver(el,target,variant),'mouseup',target,0);}await delay(125);
 }
 function anatomy(e){return [...e.svg.querySelectorAll('circle[id]')].filter(n=>!/^ref/i.test(n.id)).map(n=>[n.id,n.getAttribute('cx'),n.getAttribute('cy')]).sort((a,b)=>a[0].localeCompare(b[0]));}
 const placementTolerance=1.05; // integer CSS mouse-event coordinates + observed rounding
 async function place(handle,target,guard){
  let best={pos:screen(handle()),error:dist(screen(handle()),target),command:null,variant:0};if(best.error<=.16)return;
  const trials=[{p:target,v:3},{p:target,v:4},{p:target,v:0},{p:target,v:1},{p:target,v:2}],tried=new Set();
  for(let i=0;i<trials.length&&i<7;i++){guard();const {p,v}=trials[i];const key=[v>=3?p.x.toFixed(3):Math.round(p.x),v>=3?p.y.toFixed(3):Math.round(p.y),v].join(',');if(tried.has(key))continue;tried.add(key);
   const start=screen(handle());await drag(handle(),p,v);guard();const pos=screen(handle()),error=dist(pos,target);
   if(v>=3&&dist(start,pos)>.05&&error<best.error)fineUsed=true;
   if(error<best.error)best={pos,error,command:p,variant:v};if(error<=.16)return;
   if(error<3&&dist(start,pos)>.03&&i<2){const corrected={x:target.x+(target.x-pos.x),y:target.y+(target.y-pos.y)};trials.splice(i+1,0,{p:corrected,v});}
   if(v<3&&error<=placementTolerance)break;
  }
  guard();if(best.command&&dist(screen(handle()),target)>best.error+.08){await drag(handle(),best.command,best.variant);guard();}
 }
 function verifyPlacement(after,p){const actual=fields().ppm,sa=screen(after.a),sb=screen(after.b),errorA=dist(sa,p.points[0]),errorB=dist(sb,p.points[3]),error=Math.max(errorA,errorB);
  const markError=Math.max(...p.raw.map((point,i)=>dist(point,{x:sa.x+(sb.x-sa.x)*i/3,y:sa.y+(sb.y-sa.y)*i/3})));
  const actualGeometry=dist(coord(after.a),coord(after.b))/30;
  const positionOK=error<=placementTolerance,marksOK=markError<=Math.max(1.5,p.fitRms*2+.5),scaleOK=Math.abs(actual-p.expected)<=Math.max(.004,p.expected*.006),geometryOK=Math.abs(actual-actualGeometry)<=Math.max(.004,actualGeometry*.002);
  const detail=`Extremos: ${errorA.toFixed(2)} / ${errorB.toFixed(2)} px; marcas: ${markError.toFixed(2)} px; escala esperada/real: ${p.expected.toFixed(3)} / ${actual.toFixed(3)}; geometría SVG: ${actualGeometry.toFixed(3)} px/mm.`;
  const reasons=[!positionOK?'posición':null,!marksOK?'marcas':null,!scaleOK?'escala':null,!geometryOK?'geometría':null].filter(Boolean);
  return {actual,actualGeometry,error,markError,positionOK,marksOK,scaleOK,geometryOK,good:positionOK&&marksOK&&scaleOK&&geometryOK,detail,reasons};
 }
 // The drag API rounds to integer CSS pixels. Optimize the *pair* against
 // the actual WebCeph scale, not only distance to each fitted endpoint.
 function score(v,p){const st=Math.max(.004,p.expected*.006),gt=Math.max(.004,v.actualGeometry*.002);return Math.max(v.error/placementTolerance,v.markError/Math.max(1.5,p.fitRms*2+.5),Math.abs(v.actual-p.expected)/st,Math.abs(v.actual-v.actualGeometry)/gt);}
 async function settled(p,guard){let last='',stable=0,v;for(let i=0;i<7;i++){await delay(100);guard();const e=endpoints();v=verifyPlacement(e,p);const k=JSON.stringify([coord(e.a),coord(e.b),v.actual]);stable=k===last?stable+1:0;last=k;if(stable>=2)return v;}throw Error('WebCeph no estabilizó la escala. No se guardó.');}
 function candidateMoves(sa,sb,p,v){const dx=sb.x-sa.x,dy=sb.y-sa.y,len=Math.hypot(dx,dy);if(!len)return [];const ux=dx/len,uy=dy/len,sign=Math.sign(p.expected-v.actual)||1;const candidates=[];
  for(const [id,pos,want,sgn] of [['bottom',sb,p.points[3],sign],['top',sa,p.points[0],-sign]]){
   const bx=Math.round(pos.x),by=Math.round(pos.y);for(const [x,y] of [[Math.round(want.x),Math.round(want.y)],[bx+Math.round(ux*sgn),by+Math.round(uy*sgn)],[bx-Math.round(ux*sgn),by-Math.round(uy*sgn)],[bx-1,by],[bx+1,by],[bx,by-1],[bx,by+1]]){
    if(x===bx&&y===by||Math.hypot(x-want.x,y-want.y)>2.1)continue;const a=id==='top'?{x,y}:sa,b=id==='bottom'?{x,y}:sb;const delta=dist(a,b)-len;const pred=v.actual+delta*p.expected/dist(p.points[0],p.points[3]);const rank=Math.abs(pred-p.expected)/Math.max(.004,p.expected*.006)+.2*Math.max(dist(a,p.points[0]),dist(b,p.points[3]));candidates.push({id,x,y,rank});}}
  return candidates.sort((a,b)=>a.rank-b.rank);}
 async function refineFractional(p,guard,v){
  if(v.good||v.error>2.5||v.markError>3)return v;
  // The field may lag behind the SVG; use actual measured geometry and scale.
  // Correct symmetrical length errors without shifting the ruler midpoint.
  for(let i=0;i<2&&!v.good;i++){guard();const e=endpoints(),sa=screen(e.a),sb=screen(e.b),len=dist(sa,sb);if(!len||!v.actual)break;
   const wanted=dist(p.points[0],p.points[3]),ux=(sb.x-sa.x)/len,uy=(sb.y-sa.y)/len;
   const delta=Math.max(-.8,Math.min(.8,(p.expected-v.actual)*wanted/p.expected/2));
   const ta={x:p.points[0].x-ux*delta,y:p.points[0].y-uy*delta},tb={x:p.points[3].x+ux*delta,y:p.points[3].y+uy*delta};
   if(dist(ta,sa)<.08&&dist(tb,sb)<.08)break;
   const prior=score(v,p);await drag(endpoints().a,ta,3);guard();await drag(endpoints().b,tb,3);guard();const next=await settled(p,guard);
   if(next.good||score(next,p)<prior){v=next;continue;}
   await drag(endpoints().a,sa,3);guard();await drag(endpoints().b,sb,3);guard();v=await settled(p,guard);break;
  }return v;
 }
 async function optimizePair(p,guard,v){if(v.good||v.error>2.5||v.markError>3)return v;const handles={top:()=>endpoints().a,bottom:()=>endpoints().b};let seen=new Set();
  // Search a bounded local neighborhood. Revert only a trial that worsens the score;
  // do not keep dragging indefinitely or write the field directly.
  for(let i=0;i<6&&!v.good;i++){guard();const e=endpoints(),sa=screen(e.a),sb=screen(e.b);const candidates=candidateMoves(sa,sb,p,v);const c=candidates.find(c=>!seen.has(c.id+':'+c.x+','+c.y));if(!c)break;seen.add(c.id+':'+c.x+','+c.y);const handle=handles[c.id],prev=screen(handle());const prior=score(v,p);await drag(handle(),c,0);guard();let next=await settled(p,guard);if(next.good)return next;
   if(score(next,p)+.015<prior){v=next;continue;}
   await drag(handle(),prev,0);guard();v=await settled(p,guard);if(v.error>3||v.markError>3.5)break;
  }return v;}
 function allowManual(p,v,origAnatomy){const after=endpoints();clear();showMarks(p.raw);assistToken=layoutKey(after);manualReview={p,anatomy:origAnatomy};q('review').hidden=false;q('cancel').hidden=false;say('Regla cercana; falta verificar '+v.reasons.join(', ')+'. '+v.detail+' Ajusta los extremos si hace falta y pulsa Comprobar ajuste manual. No se guardó.');}
 async function apply(){if(busy||!pending)return;const p=pending;fineUsed=false;busy=true;q('detect').disabled=true;q('apply').disabled=true;let context=null,inputLock=null;try{
  if(!mode()||fingerprint(endpoints())!==p.token)throw Error('La imagen, la regla o el zoom cambió. Detecta nuevamente.');
  const e=endpoints(),before=[screen(e.a),screen(e.b)],beforePpm=fields().ppm,origPath=location.pathname,origImg=e.img.currentSrc,origRect=JSON.stringify(bounds(e.img)),origAnatomy=JSON.stringify(anatomy(e));
  if(!globalThis.RocaCalibrationInputGuard)throw Error('No se cargó la protección del mouse. Recarga ROCASTEIN y WebCeph.');
  inputLock=globalThis.RocaCalibrationInputGuard.start(e.svg,e.img);
  const guard=()=>{inputLock.check();if(location.pathname!==origPath||!mode()||endpoints().img.currentSrc!==origImg||JSON.stringify(bounds(endpoints().img))!==origRect)throw Error('Cambió la radiografía o el zoom. Revisa manualmente.');if(JSON.stringify(anatomy(endpoints()))!==origAnatomy)throw Error('Cambió un punto del trazado. No guardes; revisa la digitalización.');};
  context={guard,before,beforePpm};overlay?.remove();overlay=null;host.style.visibility='hidden';await delay(60);guard();
  const top=()=>endpoints().a,bottom=()=>endpoints().b;
  // Move the lower handle first only when the new upper handle would cross it.
  const order=p.points[0].y>=before[1].y-4?[[bottom,p.points[3]],[top,p.points[0]]]:[[top,p.points[0]],[bottom,p.points[3]]];
  for(const [handle,target] of order){guard();await place(handle,target,guard);}await delay(220);guard();
  let after=endpoints(),v=await settled(p,guard);
  // A move can update the other handle; correct only the residual that remains.
  if(!v.positionOK&&v.error<4){for(const [handle,target] of order){guard();if(dist(screen(handle()),target)>placementTolerance)await place(handle,target,guard);}await delay(180);guard();after=endpoints();v=await settled(p,guard);}
  if(!v.good){v=await refineFractional(p,guard,v);after=endpoints();}
  if(!v.good){v=await optimizePair(p,guard,v);after=endpoints();}
  if(!v.good){
   // Keep a nearly aligned ruler for manual inspection, but do not enable save.
   // A major deviation still uses the verified rollback path below.
   if(v.error<=2&&v.markError<=2.5&&Math.abs(v.actual-p.expected)<=p.expected*.02&&Math.abs(v.actual-v.actualGeometry)<=v.actualGeometry*.01){allowManual(p,v,origAnatomy);return;}
   throw Error('No se confirmó: '+v.reasons.join(', ')+'. '+v.detail);
  }
  clear();ready={token:fingerprint(after),ppm:v.actual,anatomy:JSON.stringify(anatomy(after))};q('save').hidden=false;say('Regla verificada · '+v.actual.toFixed(3)+' px/mm · '+p.source+'. Desfase: '+v.error.toFixed(2)+' px. '+(fineUsed?'Arrastre decimal ensayado. ':'Arrastre compatible. ')+'Revisa las cuatro divisiones y pulsa Guardar calibración y cerrar.');
 }catch(e){clear();let restored=false,assist=false;if(context){try{const {guard,before,beforePpm}=context;guard();const top=()=>endpoints().a,bottom=()=>endpoints().b;const order=before[0].y>=screen(bottom()).y-4?[[bottom,before[1]],[top,before[0]]]:[[top,before[0]],[bottom,before[1]]];for(const [handle,target] of order)await place(handle,target,guard);guard();restored=dist(screen(top()),before[0])<=.85&&dist(screen(bottom()),before[1])<=.85&&Math.abs(fields().ppm-beforePpm)<=Math.max(.004,beforePpm*.002);if(restored){showMarks(p.raw);assistToken=layoutKey(endpoints());q('cancel').hidden=false;assist=true;}}catch{}}
 say(e.message+(restored?' Se verificó la restauración.':' No se guardó; comprueba el trazado y la escala.')+(assist?' Usa las cruces verdes para colocar la regla manualmente.':''));
 }finally{inputLock?.release();host.style.visibility='';busy=false;q('detect').disabled=false;q('apply').disabled=false;}}
 q('review').onclick=async()=>{if(busy||!manualReview)return;busy=true;q('review').disabled=true;try{const {p,anatomy:original}=manualReview;const guard=()=>{if(!mode()||layoutKey(endpoints())!==assistToken||JSON.stringify(anatomy(endpoints()))!==original)throw Error('Cambió la radiografía, el zoom o el trazado. Detecta nuevamente.');};guard();const v=await settled(p,guard);guard();if(!v.good){say('Aún no se confirma '+v.reasons.join(', ')+'. '+v.detail+' Corrige manualmente. No se guardó.');return;}const e=endpoints();clear();ready={token:fingerprint(e),ppm:v.actual,anatomy:original};q('save').hidden=false;say('Regla verificada · '+v.actual.toFixed(3)+' px/mm. Revisa las cuatro marcas y pulsa Guardar calibración y cerrar.');}catch(e){clear();say(e.message);}finally{busy=false;q('review').disabled=false;}};
 // Match actual visible native controls, including styled divs and nested controls.
 const nativeSelector='button,a,[role="button"],input[type="button"],input[type="submit"],.btn,[onclick],[tabindex]';
 const normLabel=x=>String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const label=n=>normLabel((n.matches('input')?n.value:n.innerText)||n.getAttribute('aria-label')||n.textContent);
 function nativeVisible(n){if(!(n instanceof HTMLElement)||!n.isConnected||n.closest('#roc-calibration-pilot,#roc-guide-extension,#roca-results-v4,[hidden],[aria-hidden="true"]'))return false;const r=n.getBoundingClientRect();if(!r.width||!r.height)return false;for(let el=n;el;el=el.parentElement){const c=getComputedStyle(el);if(c.display==='none'||c.visibility!=='visible'||Number(c.opacity)===0)return false;}return true;}
 const disabled=n=>!!n.disabled||n.classList.contains('disabled')||n.getAttribute('aria-disabled')==='true';
 const savedLabel=/^(guardado|saved)$/;const savingLabel=/^(guardando|saving)(?:\.{1,3}|…)?$/;const saveLabel=/^(guardar|save)$/;
 function nativeCandidates(root,pattern){if(!root)return [];const all=[...root.querySelectorAll(nativeSelector)].filter(n=>nativeVisible(n)&&pattern.test(label(n)));return all.filter(n=>!all.some(other=>other!==n&&other.contains(n)));}
 // Use exactly the same resolver as Guardar e ir a Análisis in content.js.
 function sharedSave(preferred=null){return globalThis.RocaNativeSave?.state(preferred)||null;}
 q('save').onclick=async()=>{if(busy||!ready)return;busy=true;saving=true;q('save').disabled=true;let closed=false,clicked=false;try{
 const e=endpoints();if(!mode()||fingerprint(e)!==ready.token||JSON.stringify(anatomy(e))!==ready.anatomy)throw Error('La calibración cambió. Detecta nuevamente o guarda manualmente.');
 const modal=document.querySelector('#guide_ruler_set_modal');const closes=nativeCandidates(modal,/^(cerrar|close)$/).filter(n=>!disabled(n));
 if(closes.length!==1)throw Error('No se identificó Cerrar en la ventana de calibración. Cierra y guarda manualmente.');
 const path=location.pathname,src=e.img.currentSrc,original=ready.anatomy;
 const sameCase=()=>{const svg=document.querySelector('svg#original_canvas');return location.pathname===path&&document.querySelector('img#original')?.currentSrc===src&&svg&&JSON.stringify(anatomy({svg}))===original;};
 say('Cerrando la calibración…');closes[0].click();for(let i=0;i<30&&mode();i++)await delay(100);
 if(mode())throw Error('WebCeph no confirmó el cierre. Cierra y guarda manualmente.');closed=true;
 if(!sameCase())throw Error('Cambió la radiografía o el trazado. Revisa antes de guardar.');
 say('Buscando Guardar en WebCeph…');let state=null;
 for(let i=0;i<50;i++){if(!sameCase()||mode())throw Error('Cambió la radiografía o el modo. Revisa antes de guardar.');state=sharedSave();if(state&&(savedLabel.test(state.label)||savingLabel.test(state.label)||!state.disabled))break;await delay(100);}
 if(!state)throw Error('Calibración cerrada. La función de guardado de la guía no identificó un control único. Pulsa Guardar en WebCeph.');
 const preferred={el:state.el,id:state.el.id};
 if(saveLabel.test(state.label)&&!state.disabled){state.el.click();clicked=true;}else if(!savedLabel.test(state.label)&&!savingLabel.test(state.label))throw Error('Calibración cerrada. Guardar no está disponible. Comprueba WebCeph.');
 say('Esperando confirmación de WebCeph…');let confirmed=false;
 for(let i=0;i<72;i++){if(!sameCase()||mode())throw Error('Cambió la radiografía o el trazado durante el guardado. Comprueba WebCeph.');state=sharedSave(preferred);if(state&&savedLabel.test(state.label)){confirmed=true;break;}await delay(250);}
 if(!confirmed)throw Error('Calibración cerrada. '+(clicked?'Se pulsó Guardar, pero WebCeph no confirmó el guardado.':'WebCeph no confirmó el guardado.')+' Comprueba el estado antes de continuar.');
 clear();say('Calibración guardada. Continúa con Puntos extra.');await delay(850);
 }catch(e){say(e.message);if(closed||!mode()){clear();window.alert('ROCASTEIN: '+e.message);}}finally{saving=false;busy=false;q('save').disabled=false;}};
 q('detect').onclick=detect;q('apply').onclick=apply;q('cancel').onclick=()=>{if(busy)return;clear();say('Marcas retiradas. No se guardó la calibración.');};
 function sync(){const on=mode();host.style.display=(on||saving)?'block':'none';const key=on?location.pathname+'|'+(document.querySelector('#original')?.currentSrc||''):null;
 if(on&&(!wasOn||key!==caseKey)){wasOn=true;caseKey=key;if(autoTimer)clearTimeout(autoTimer);if(!busy)clear();let attempts=0;const start=()=>{if(!mode()||caseKey!==key)return;if(busy){if(attempts++<12)autoTimer=setTimeout(start,350);return;}try{endpoints();fields();}catch{if(attempts++<12){autoTimer=setTimeout(start,350);return;}}if(!pending&&!ready&&!scheduled)detect();};autoTimer=setTimeout(start,500);}
 if(!on){wasOn=false;caseKey=null;if(autoTimer)clearTimeout(autoTimer);if(!busy){clear();say('Mantén visibles las cuatro marcas blancas.');}}else if(ready&&!busy){try{if(fingerprint(endpoints())!==ready.token){clear();say('La calibración cambió. Detecta nuevamente.');}}catch{clear();}}else if(pending&&!busy){try{if(fingerprint(endpoints())!==pending.token){clear();say('La imagen o la regla cambió. Detecta nuevamente.');}}catch{clear();}}else if(assistToken&&!busy){try{if(layoutKey(endpoints())!==assistToken){clear();say('Ajuste manual en curso. Revisa y guarda desde WebCeph.');}}catch{clear();}}}
 setInterval(sync,300);sync();
 chrome.runtime.onMessage.addListener((m,sender,reply)=>{if(m?.type!=='roc-cal-start'||sender.id!==chrome.runtime.id)return;if(!mode()){reply({ok:false,message:'Abre Calibrar imagen primero.'});return;}reply({ok:true,message:'Detectando marcas en WebCeph…'});setTimeout(detect,350);});
})();
